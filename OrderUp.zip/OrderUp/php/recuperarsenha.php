<?php
require_once('conexao.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Esqueci Minha Senha</title>
</head>

<body>

    <div class="container">
        <div class="logo-container">
            <p class="senai-nome">OrderUp</p>
        </div>
        <header>Esqueceu sua senha</header>

        
            <form action="" method="POST">
                <div class="quadro_login">
                    <label class="email">Email: <input type="text" id="usuario" name="email"
                            placeholder="Email" required></label>
                    <label class="senha">Nova senha: <input type="password" id="senha" name="senha" placeholder="Senha"
                            required></label>
                    <label class="confsenha">Confirme sua senha: <input type="password" id="confsenha" name="confsenha"
                            placeholder="Confirme sua senha" required></label>
                    <button class="nextBtn" type="submit" name="submit">Mudar Senha</button>
                </div>
            </form>
        
        <?php

        // Verifica se o botão de envio foi clicado
        if (isset($_POST['submit'])) {

            // Valida os dados do formulário
            $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
            $senha = filter_var($_POST['senha'], FILTER_SANITIZE_STRING);
            $confsenha = filter_var($_POST['confsenha'], FILTER_SANITIZE_STRING);

            // Verifica se as senhas batem
            if ($senha === $confsenha) {

                // Atualiza a senha no banco de dados
                $sql = "UPDATE usuarios SET senha = '$confsenha' WHERE email = '$email'";
                $result = mysqli_query($conn, $sql);

                // Verifica se a atualização foi bem-sucedida
                if ($result) {
                    echo "<script>alert('Senha atualizada com sucesso')</script>";
                } else {
                    echo "<div class ='quadro'>";
                    echo "Erro ao atualizar senha: " . mysqli_error($conn);
                    echo '<a href="index.php"<button class="nextBtn">Voltar</button></a>';
                    echo "</div>";
                }
            } else {
                echo "<div class ='quadro'>";
                echo "Senhas não batem";
                echo '<a href="esqueceu_senha.php"<button class="nextBtn">Voltar</button></a>';
                echo "</div>";
            }
        }
        ?>

</body>

</html>